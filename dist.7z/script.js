function showSection(id, link) {

  document.querySelectorAll(".section").forEach((sec) => {

    sec.classList.remove("active");

  });

  document.getElementById(id).classList.add("active");

  document.querySelectorAll(".nav-link").forEach((nav) => {

    nav.classList.remove("active");

  });

  link.classList.add("active");

}